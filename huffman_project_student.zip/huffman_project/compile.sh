#!/usr/bin/env bash

make
make submission
