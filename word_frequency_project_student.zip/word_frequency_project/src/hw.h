#ifndef __HW3_H
#define __HW3_H

#include "words.h"
#include "wset.h"

#endif
