#!/usr/bin/env bash

./compile.sh
java -cp "classes:lib/*" RunTests