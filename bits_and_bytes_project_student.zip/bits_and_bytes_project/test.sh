#!/usr/bin/env bash

./compile.sh
./all_tests