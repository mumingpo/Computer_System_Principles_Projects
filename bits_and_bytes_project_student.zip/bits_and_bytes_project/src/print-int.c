#include <stdio.h>
#include "bits_and_bytes.h"

int main() {
  print_int();
  return 0;
}
