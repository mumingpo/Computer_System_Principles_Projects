#include <stdio.h>

void print_it() {
  // TODO
  printf("TODO");
}

void print_int() {
  // TODO
  printf("TODO");
}

void print_float() {
  // TODO
  printf("TODO");
}

void print_char() {
  // TODO
  printf("TODO");
}

void packing_bytes() {
  // TODO
  printf("TODO");
}

void unpacking_bytes() {
  // TODO
  printf("TODO");
}

void print_bits() {
  // TODO
  printf("TODO");
}

void extracting_fields() {
  // TODO
  printf("TODO");
}

void updating_fields() {
  // TODO
  printf("TODO");
}
